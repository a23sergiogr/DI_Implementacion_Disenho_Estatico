function cambiarImagenPrincipal(src) {
    const mainImage = document.getElementById("img1");
    mainImage.src = src;
}